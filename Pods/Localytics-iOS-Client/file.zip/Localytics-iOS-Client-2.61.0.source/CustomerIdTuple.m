//
//  CustomerIdTuple.m
//  dev_profile
//
//  Created by aspitz on 6/12/14.
//
//

#import "CustomerIdTuple.h"

@implementation CustomerIdTuple

+ (id)tuple{
    return [[[CustomerIdTuple alloc]init]autorelease];
}

@end
